package com.mytv.launcher

import android.app.Activity
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.StatFs
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.widget.VideoView
import android.media.MediaPlayer
import android.graphics.Color
import android.widget.FrameLayout
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 14, 26)
    private val panel = Color.rgb(22, 30, 49)
    private val accent = Color.rgb(91, 139, 255)
    private lateinit var root: LinearLayout
    private lateinit var videoBackground: VideoView
    private lateinit var appGrid: LinearLayout
    private lateinit var status: TextView
    private var currentCategory = "All"
    private var searchQuery = ""
    private var wallpaperUri: Uri? = null
    private data class AppEntry(val label: String, val pkg: String, val icon: android.graphics.drawable.Drawable)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        buildUi()
        refreshApps()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(34, 22, 34, 22)
            setBackgroundColor(Color.TRANSPARENT)
            isFocusableInTouchMode = true
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = TextView(this).apply {
            text = "MY TV  /  HOME"
            textSize = 23f; setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        status = TextView(this).apply { textSize = 15f; setTextColor(Color.LTGRAY); gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL }
        header.addView(brand, LinearLayout.LayoutParams(0, 56, 1f))
        header.addView(status, LinearLayout.LayoutParams(0, 56, 1f))
        root.addView(header)
        val hero = TextView(this).apply {
            text = "Your entertainment, beautifully organised."
            textSize = 27f; setTextColor(Color.WHITE); setPadding(0, 14, 0, 18)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        root.addView(hero)
        val subtitle = TextView(this).apply {
            text = "SPOTLIGHT  •  APPS  •  GAMES  •  UTILITIES"
            textSize = 11f; setTextColor(Color.rgb(135, 157, 197)); letterSpacing = .18f
            setPadding(0, 0, 0, 12)
        }
        root.addView(subtitle)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        listOf("All", "Video", "Games", "Tools", "Categories", "Wallpaper", "Weather", "TV settings").forEach { name ->
            val b = button(name) {
                when (name) {
                    "Wallpaper" -> chooseWallpaper()
                    "Weather" -> chooseWeatherCity()
                    "Categories" -> chooseCategory()
                    "TV settings" -> startActivity(Intent(Settings.ACTION_SETTINGS))
                    else -> { currentCategory = name; searchQuery = ""; refreshApps() }
                }
            }
            actions.addView(b, LinearLayout.LayoutParams(0, 48, 1f).apply { setMargins(4, 4, 4, 4) })
        }
        root.addView(actions)
        val appTitle = TextView(this).apply {
            text = "YOUR APPS"; textSize = 14f; setTextColor(Color.LTGRAY)
            setPadding(0, 18, 0, 8); letterSpacing = .12f
        }
        root.addView(appTitle)
        appGrid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { isFillViewport = true; isVerticalScrollBarEnabled = false; addView(appGrid) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val footer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Search", "Favourites", "Recent", "Control centre", "TV utilities", "System info").forEach { name ->
            footer.addView(button(name) {
                when(name) {
                    "Search" -> searchApps()
                    "Favourites" -> { currentCategory = "Favourites"; searchQuery = ""; refreshApps() }
                    "Recent" -> showRecent()
                    "Control centre" -> showControlCentre()
                    "TV utilities" -> showUtilities()
                    "System info" -> showSystemInfo()
                    else -> startActivity(Intent(Settings.ACTION_SETTINGS))
                }
            }, LinearLayout.LayoutParams(0, 52, 1f).apply { setMargins(5, 8, 5, 0) })
        }
        root.addView(footer)
        val backdrop = FrameLayout(this)
        videoBackground = VideoView(this)
        backdrop.addView(videoBackground, FrameLayout.LayoutParams(-1, -1))
        val shade = View(this).apply { setBackgroundColor(Color.argb(112, 4, 8, 18)) }
        backdrop.addView(shade, FrameLayout.LayoutParams(-1, -1))
        backdrop.addView(root, FrameLayout.LayoutParams(-1, -1))
        setContentView(backdrop)
        playAmbientBackground()
        updateClock()
        getPreferences(MODE_PRIVATE).getString("weather_city", null)?.let { refreshWeather(it) }
    }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label; textSize = 13f; isAllCaps = false
        setTextColor(Color.WHITE); setBackgroundColor(panel); isFocusable = true
        setOnClickListener { action() }
        setOnFocusChangeListener { v, focused ->
            v.setBackgroundColor(if (focused) accent else panel)
            v.scaleX = if (focused) 1.04f else 1f
            v.scaleY = if (focused) 1.04f else 1f
        }
    }

    private fun refreshApps() {
        appGrid.removeAllViews()
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val hidden = getPreferences(MODE_PRIVATE).getStringSet("hidden_apps", emptySet()) ?: emptySet()
        val favourites = getPreferences(MODE_PRIVATE).getStringSet("favourite_apps", emptySet()) ?: emptySet()
        val apps = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .mapNotNull { ri ->
                val pkg = ri.activityInfo.packageName
                try { AppEntry(ri.loadLabel(pm).toString(), pkg, ri.loadIcon(pm)) } catch (_: Exception) { null }
            }.distinctBy { it.pkg }.filter { it.pkg != packageName && it.pkg !in hidden }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }

        val filtered = apps.filter { app ->
            when(currentCategory) {
                "Video" -> app.label.containsAny("youtube","video","netflix","tubi","prime","plex","media","disney")
                "Games" -> app.label.containsAny("game","asphalt","play","racing")
                "Tools" -> app.label.containsAny("setting","file","browser","clean","remote","tool")
                "Favourites" -> app.pkg in favourites
                else -> currentCategory == "All" || getPreferences(MODE_PRIVATE).getString("cat_${app.pkg}", "") == currentCategory
            } && (searchQuery.isBlank() || app.label.contains(searchQuery, true))
        }

        if (currentCategory == "All") {
            if(searchQuery.isBlank()) addSection("Your entertainment", apps.filter { it.pkg in favourites }.ifEmpty { apps.filter { it.label.containsAny("youtube","netflix","tubi","prime","video") } }.take(8))
            addSection("Your favourites", apps.filter { it.pkg in favourites })
            addSection("All apps", apps)
        } else {
            addSection(if (currentCategory == "Favourites") "Pinned favourites" else currentCategory, filtered)
        }
        if (appGrid.childCount == 0) {
            appGrid.addView(TextView(this).apply {
                text = if(currentCategory == "Favourites") "Long-press an app and choose Add to favourites." else "No apps found here."
                setTextColor(Color.LTGRAY); textSize = 18f; setPadding(12, 30, 12, 30)
            })
        }
    }

    private fun addSection(title: String, apps: List<AppEntry>) {
        if (apps.isEmpty()) return
        val heading = TextView(this).apply {
            text = title.uppercase(Locale.getDefault())
            textSize = 13f; setTextColor(Color.rgb(174, 190, 220))
            letterSpacing = .14f; setPadding(5, 18, 0, 8)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        appGrid.addView(heading, LinearLayout.LayoutParams(-1, 42))
        val rail = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        apps.forEach { app ->
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setPadding(12, 12, 12, 10); setBackgroundColor(panel)
                isFocusable = true; isClickable = true
                setOnFocusChangeListener { v, focused ->
                    v.setBackgroundColor(if(focused) accent else panel)
                    v.animate().scaleX(if(focused) 1.09f else 1f).scaleY(if(focused) 1.09f else 1f).setDuration(130).start()
                    v.elevation = if(focused) 12f else 2f
                }
                setOnClickListener { launch(app.pkg) }
                setOnLongClickListener { showAppOptions(app); true }
            }
            val icon = ImageView(this).apply { setImageDrawable(app.icon); scaleType = ImageView.ScaleType.FIT_CENTER }
            tile.addView(icon, LinearLayout.LayoutParams(72, 72))
            val label = TextView(this).apply {
                text = app.label + if(app.pkg in (getPreferences(MODE_PRIVATE).getStringSet("favourite_apps", emptySet()) ?: emptySet())) "  ★" else ""
                textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                maxLines = 2; setPadding(0, 8, 0, 0)
            }
            tile.addView(label, LinearLayout.LayoutParams(118, 42))
            val lp = LinearLayout.LayoutParams(142, 142).apply { setMargins(5, 5, 9, 12) }
            rail.addView(tile, lp)
        }
        val horizontal = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(rail)
        }
        appGrid.addView(horizontal, LinearLayout.LayoutParams(-1, 158))
    }

    private fun searchApps() {
        val field = EditText(this).apply { hint = "Search installed apps"; setSingleLine(true) }
        android.app.AlertDialog.Builder(this).setTitle("Spotlight search").setView(field)
            .setPositiveButton("Search") { _, _ ->
                searchQuery = field.text.toString().trim()
                currentCategory = "All"
                refreshApps()
                if(searchQuery.isNotEmpty()) Toast.makeText(this, "Search results for $searchQuery", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showControlCentre() {
        val options = arrayOf("Wi-Fi / Network", "Bluetooth", "Display", "Sound", "Change background video", "Wallpaper image", "Weather location", "Device information", "Android settings")
        android.app.AlertDialog.Builder(this).setTitle("Control centre").setItems(options) { _, i ->
            when(i) {
                0 -> openSetting(Settings.ACTION_WIFI_SETTINGS)
                1 -> openSetting(Settings.ACTION_BLUETOOTH_SETTINGS)
                2 -> openSetting(Settings.ACTION_DISPLAY_SETTINGS)
                3 -> openSetting(Settings.ACTION_SOUND_SETTINGS)
                4 -> chooseAmbientVideo()
                5 -> chooseWallpaper()
                6 -> chooseWeatherCity()
                7 -> showSystemInfo()
                else -> openSetting(Settings.ACTION_SETTINGS)
            }
        }.show()
    }

    private fun openSetting(action: String) {
        try { startActivity(Intent(action)) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }
    private fun String.containsAny(vararg words: String) = words.any { contains(it, true) }
    private fun launch(pkg: String) {
        packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
        updateClock()
    }
    private fun showAppOptions(app: AppEntry) {
        val prefs = getPreferences(MODE_PRIVATE)
        val favs = prefs.getStringSet("favourite_apps", emptySet())?.toMutableSet() ?: mutableSetOf()
        val choices = arrayOf("Open", if(app.pkg in favs) "Remove from favourites" else "Add to favourites", "Assign custom category", "Hide app", "App info")
        android.app.AlertDialog.Builder(this).setTitle(app.label).setItems(choices) { _, which ->
            if(which == 0) launch(app.pkg)
            if(which == 1) {
                if(app.pkg in favs) favs.remove(app.pkg) else favs.add(app.pkg)
                prefs.edit().putStringSet("favourite_apps", favs).apply()
                refreshApps()
            }
            if(which == 2) {
                val edit = EditText(this).apply { hint = "e.g. Favourites, Kids, Streaming"; setText(getPreferences(MODE_PRIVATE).getString("cat_${app.pkg}", "")) }
                android.app.AlertDialog.Builder(this).setTitle("Category for ${app.label}").setView(edit)
                    .setPositiveButton("Save") { _, _ ->
                        val category = edit.text.toString().trim()
                        getPreferences(MODE_PRIVATE).edit().putString("cat_${app.pkg}", category).apply()
                        currentCategory = category.ifBlank { "All" }; refreshApps()
                    }.setNegativeButton("Cancel", null).show()
            }
            if(which == 3) {
                val hidden = prefs.getStringSet("hidden_apps", emptySet())?.toMutableSet() ?: mutableSetOf()
                hidden.add(app.pkg); prefs.edit().putStringSet("hidden_apps", hidden).apply(); refreshApps()
            }
            if(which == 4) startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}")))
        }.show()
    }
    private fun showRecent() {
        val lines = try {
            val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
            val end = System.currentTimeMillis()
            usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, end - 86400000L, end)
                .sortedByDescending { it.lastTimeUsed }.take(8)
                .mapNotNull { s -> try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(s.packageName, 0)).toString() } catch (_: Exception) { null } }
                .distinct().joinToString("\n")
        } catch (_: Exception) { "" }
        android.app.AlertDialog.Builder(this).setTitle("Recently used").setMessage(if(lines.isBlank()) "Recent-app history needs Usage Access. Open Settings > Security/Privacy > Usage access and allow My TV Launcher." else lines)
            .setPositiveButton("OK", null).setNeutralButton("Usage access") { _, _ -> startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }.show()
    }
    private fun showUtilities() {
        val items = arrayOf("Display settings", "Sound settings", "Network settings", "Bluetooth settings", "Installed apps")
        android.app.AlertDialog.Builder(this).setTitle("TV utilities").setItems(items) { _, i ->
            val action = when(i) {
                0 -> Settings.ACTION_DISPLAY_SETTINGS
                1 -> Settings.ACTION_SOUND_SETTINGS
                2 -> Settings.ACTION_WIFI_SETTINGS
                3 -> Settings.ACTION_BLUETOOTH_SETTINGS
                else -> Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS
            }
            try { startActivity(Intent(action)) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }.show()
    }
    private fun showSystemInfo() {
        val memory = android.app.ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager).getMemoryInfo(memory)
        val used = (memory.totalMem - memory.availMem) / 1048576
        val total = memory.totalMem / 1048576
        val stat = StatFs(android.os.Environment.getDataDirectory().path)
        val free = stat.availableBytes / 1073741824.0
        val all = stat.totalBytes / 1073741824.0
        android.app.AlertDialog.Builder(this).setTitle("Device status")
            .setMessage("Device RAM: $used MB used / $total MB total\nInternal storage: %.1f GB free / %.1f GB total".format(free, all))
            .setPositiveButton("OK", null).show()
    }

    private fun chooseAmbientVideo() {
        val labels = arrayOf("Aurora blue (offline)", "Nebula purple (offline)", "Turn background video off")
        android.app.AlertDialog.Builder(this).setTitle("Ambient background")
            .setItems(labels) { _, which ->
                val value = when(which) { 0 -> "aurora"; 1 -> "nebula"; else -> "off" }
                getPreferences(MODE_PRIVATE).edit().putString("ambient_video", value).apply()
                playAmbientBackground()
            }.show()
    }

    private fun playAmbientBackground() {
        if(!::videoBackground.isInitialized) return
        try {
            videoBackground.stopPlayback()
            val mode = getPreferences(MODE_PRIVATE).getString("ambient_video", "aurora")
            val resource = when(mode) {
                "nebula" -> R.raw.nebula_ambient
                "off" -> 0
                else -> R.raw.aurora_ambient
            }
            if(resource == 0) {
                videoBackground.visibility = View.GONE
                return
            }
            videoBackground.visibility = View.VISIBLE
            videoBackground.setVideoURI(Uri.parse("android.resource://$packageName/$resource"))
            videoBackground.setOnPreparedListener { player: MediaPlayer ->
                player.isLooping = true
                player.setVolume(0f, 0f)
                videoBackground.start()
            }
            videoBackground.setOnErrorListener { _, _, _ ->
                videoBackground.visibility = View.GONE
                false
            }
        } catch (_: Exception) {
            videoBackground.visibility = View.GONE
        }
    }

    private fun chooseWallpaper() {
        val pick = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="image/*"; addCategory(Intent.CATEGORY_OPENABLE); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }
        startActivityForResult(pick, 41)
    }
    @Deprecated("Legacy result API retained for older TV compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(requestCode == 41 && resultCode == RESULT_OK) {
            wallpaperUri = data?.data
            try { wallpaperUri?.let { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } } catch (_: Exception) {}
            wallpaperUri?.let { uri ->
                try {
                    root.background = android.graphics.drawable.Drawable.createFromStream(contentResolver.openInputStream(uri), null)
                } catch (_: Exception) { Toast.makeText(this, "Could not load wallpaper", Toast.LENGTH_SHORT).show() }
            }
        }
    }

    private fun chooseCategory() {
        val cats = getPreferences(MODE_PRIVATE).all.values.filterIsInstance<String>()
            .filter { it.isNotBlank() }.distinct().sorted()
        val options = (listOf("All") + cats).distinct().toTypedArray()
        android.app.AlertDialog.Builder(this).setTitle("Your app categories").setItems(options) { _, i ->
            currentCategory = options[i]; refreshApps()
        }.setPositiveButton("Done", null).show()
    }

    private fun chooseWeatherCity() {
        val edit = EditText(this).apply {
            hint = "Enter city (for example, Jos)"
            setText(getPreferences(MODE_PRIVATE).getString("weather_city", ""))
        }
        android.app.AlertDialog.Builder(this).setTitle("Weather location").setMessage("Choose a city for the dashboard weather.")
            .setView(edit).setPositiveButton("Save") { _, _ ->
                val city = edit.text.toString().trim()
                if(city.isNotEmpty()) {
                    getPreferences(MODE_PRIVATE).edit().putString("weather_city", city).apply()
                    refreshWeather(city)
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun refreshWeather(city: String) {
        status.text = "Loading weather for $city…"
        Thread {
            try {
                val geo = JSONObject(URL("https://geocoding-api.open-meteo.com/v1/search?name=${java.net.URLEncoder.encode(city, "UTF-8")}&count=1&language=en&format=json").readText())
                val place = geo.getJSONArray("results").getJSONObject(0)
                val lat = place.getDouble("latitude")
                val lon = place.getDouble("longitude")
                val weather = JSONObject(URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code&timezone=auto").readText())
                    .getJSONObject("current")
                val temp = weather.getDouble("temperature_2m").toInt()
                val code = weather.getInt("weather_code")
                val condition = when(code) {
                    0 -> "Clear"; 1,2 -> "Mostly clear"; 3 -> "Cloudy"; 45,48 -> "Fog"
                    51,53,55,61,63,65,80,81,82 -> "Rain"; 71,73,75,77,85,86 -> "Snow"
                    95,96,99 -> "Thunderstorm"; else -> "Current conditions"
                }
                runOnUiThread { status.text = "${place.getString("name")}  •  ${temp}°C $condition\n${SimpleDateFormat("EEE, d MMM  •  HH:mm", Locale.getDefault()).format(Date())}" }
            } catch (_: Exception) {
                runOnUiThread { updateClock(); Toast.makeText(this, "Weather unavailable. Check Wi-Fi and city name.", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun updateClock() {
        status.text = SimpleDateFormat("EEE, d MMM  •  HH:mm", Locale.getDefault()).format(Date()) + "\nHi3751V350 Android TV"
    }
    override fun onResume() {
        super.onResume()
        if(::videoBackground.isInitialized && videoBackground.visibility == View.VISIBLE && !videoBackground.isPlaying) playAmbientBackground()
        if(::status.isInitialized) {
            val city = getPreferences(MODE_PRIVATE).getString("weather_city", null)
            if(city.isNullOrBlank()) updateClock() else refreshWeather(city)
        }
    }
    override fun onPause() {
        if(::videoBackground.isInitialized) videoBackground.pause()
        super.onPause()
    }
    override fun onDestroy() {
        if(::videoBackground.isInitialized) videoBackground.stopPlayback()
        super.onDestroy()
    }
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if(keyCode == KeyEvent.KEYCODE_MENU) { startActivity(Intent(Settings.ACTION_SETTINGS)); return true }
        return super.onKeyDown(keyCode, event)
    }
}
