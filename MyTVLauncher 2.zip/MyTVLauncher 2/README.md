# My TV Launcher

A lightweight, remote-friendly Android TV home launcher for Android 5.0+ (minSdk 21), prepared for the Hi3751V350 Android TV.

## Included
- Android TV HOME and Leanback launcher entry points
- Two bundled 12-second ambient background videos (Aurora and Nebula), auto-playing muted and looping offline
- tvOS-inspired horizontal app shelves with animated focus scaling and premium dark styling
- Continue-watching-style and all-app shelves
- Persistent favourites / pinned apps and hide-app controls
- Spotlight-style app search entry point
- Control Centre shortcuts for network, Bluetooth, display, sound, wallpaper, weather and settings
- App dashboard with remote-friendly focus states
- Video / Games / Tools filters (heuristic name matching)
- Recently-used list (requires granting Usage Access in TV settings)
- Custom image wallpaper picker
- TV utility shortcuts and system settings
- Launcher process-memory and internal-storage display
- Clock and device label
- GitHub Actions cloud build workflow

## Build APK on an iPhone (cloud build)
1. Create or sign in to a GitHub account in Safari.
2. Create a **public or private** repository named `my-tv-launcher`.
3. Upload the contents of this project ZIP to the repository root (not the ZIP file itself). Include the hidden `.github` folder.
4. Open the repository's **Actions** tab. Select **Build Android TV Launcher**, then **Run workflow**. A push to `main` also starts a build.
5. Open the completed workflow run, scroll to **Artifacts**, and download `MyTVLauncher-debug`.
6. Extract the artifact ZIP in the iPhone Files app. The APK inside is `app-debug.apk`.

## Install to the TV using ADB from the iPhone
Your TV and iPhone must be on the same Wi-Fi network if using wireless ADB. Use the ADB app/terminal you already used to connect to the TV.
1. Connect to the TV's current IP and ADB port (commonly 5555; use the port shown by your TV's wireless debugging screen).
2. Transfer `app-debug.apk` to the TV using your ADB app's file-send/push feature, or use its install APK feature if available.
3. If your terminal supports `install`, run:
   `install /path/to/app-debug.apk`
   If it expects raw ADB syntax, run:
   `adb install -r /path/to/app-debug.apk`
   Do not type `adb shell` first if the app says the console already runs commands on the TV.
4. Press Home on the TV remote. Choose **My TV Launcher** and select **Always** if Android offers a home-app chooser.

## Important limitations / next improvements
- The recent-app list requires manually granting Usage Access; Android restricts this permission.
- Device RAM uses Android's ActivityManager memory statistics; firmware may restrict some reported values.
- Weather is not yet connected; the dashboard currently shows local date/time. A weather provider and location permission/choice can be added next.
- Categories currently use app-name matching. Custom per-app category assignment and favourites persistence are planned next.
- Wallpaper selection uses the TV's document picker; some TV firmware may not include one.
- The debug APK is unsigned for Play Store release but Android can install it locally.

## Troubleshooting
- If app icons are missing, check the Android package visibility / launcher support of the firmware.
- If the app does not appear as a Home choice, reboot once and check Settings > Apps > Default apps > Home app.
- Keep your existing launcher installed until the new one is tested. To revert, choose the original launcher under Default Home app.

## Version 1.1 additions
- Horizontal shelves styled after modern TV interfaces (inspired by tvOS; not affiliated with Apple).
- Focus scaling/elevation for directional remote navigation.
- Persistent favourites and hidden-app list.
- Control Centre and Spotlight-style search entry point.
- Physical device RAM and internal storage display.

## Version 1.2 — Offline motion backgrounds
- Includes two original generated 720p ambient MP4 loops in `app/src/main/res/raw/`.
- Aurora and Nebula play automatically, muted, without network access or mobile data.
- Select the background or turn it off in Control Centre > Change background video.
- The videos are packaged inside the APK; no streaming or download is required at runtime.
